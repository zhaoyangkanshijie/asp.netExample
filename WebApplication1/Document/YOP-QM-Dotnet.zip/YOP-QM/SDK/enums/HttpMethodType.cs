﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SDK.enums
{
  public enum HttpMethodType
  {
    GET,
    POST
  }
}
