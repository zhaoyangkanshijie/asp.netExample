﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SDK.yop.unmarshaller
{
    public interface YopMarshaller
    {
        //   /**
        // * 负责将请求方法返回的响应对应流化为相应格式的内容
        // */
        //   void marshal(object obj, MemoryStream outputStream);

        ///**
        // * 将字符串反序列化为相应的对象
        // */
        //<T> T unmarshal(string content, Class<T> objectType);

        //   /**
        //    * 返回ObjectMapper
        //    */
        //   ObjectMapper getObjectMapper() throws IOException;
    }
}
