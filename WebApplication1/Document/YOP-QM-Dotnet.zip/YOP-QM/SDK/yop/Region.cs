﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SDK.yop
{
    public enum Region
    {
        CN_N1,//"sj"
        CN_N2//"dj"
    }
}
