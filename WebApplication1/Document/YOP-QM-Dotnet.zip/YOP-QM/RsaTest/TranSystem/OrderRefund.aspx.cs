﻿using System;
using SDK.yop.client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RsaTest.TranSystem
{
    public partial class OrderRefund : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            requestNo.Value = "Refund" + GetTimeStamp();
        }
        public static string GetTimeStamp()
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalMilliseconds).ToString();
        }
        protected void Button1_Click1(object sender, EventArgs e)
        {
            string merchantNo = CustomerConfig.MerchantNo;
            string privatekey = CustomerConfig.PrivateKey;
            string yopPublicKey = CustomerConfig.YopPublicKey;

            YopRequest request = new YopRequest(merchantNo, privatekey,
                 "https://open.yeepay.com/yop-center", yopPublicKey);

            request.addParam("requestNo", requestNo.Value);
            request.addParam("trxRequestNo", trxRequestNo.Value);
            request.addParam("refundAmount", refundAmount.Value);
            /*
            request.addParam("refundWay", refundWay.Value);
            request.addParam("couponNos", couponNos.Value);
            request.addParam("serverCallbackUrl", serverCallbackUr.Value);
            request.addParam("webCallbackUrl", webCallbackUrl.Value);
           */
            System.Diagnostics.Debug.WriteLine(request.toQueryString());
            YopResponse response = YopClient3.postRsa("/rest/v1.0/payplus/refund/refund", request);


            if (response.isSuccess() && response.validSign)
            {
                Response.Write("返回结果签名验证成功!" + "<br>");
                Response.Write("response.resul:" + response.result + "<br>");
                JObject obj = (JObject)JsonConvert.DeserializeObject(response.result.ToString());
                code.Text = Convert.ToString(obj["code"]);
                message.Text = Convert.ToString(obj["message"]);
                refundAmountRe.Text = Convert.ToString(obj["refundAmount"]);
                refundWayRe.Text = Convert.ToString(obj["refundWay"]);
                refundCoupons.Text = Convert.ToString(obj["refundCoupons"]);
                status.Text = Convert.ToString(obj["status"]);
             
            }
            else
            {
                string errorText = JsonConvert.SerializeObject(response.error);
                Response.Write("请求失败，返回结果:" + errorText + "<br>");
            }

        }
    }
}