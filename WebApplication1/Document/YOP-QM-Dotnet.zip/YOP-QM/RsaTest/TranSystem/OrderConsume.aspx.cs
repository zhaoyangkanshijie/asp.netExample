﻿using System;
using SDK.yop.client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RsaTest.TranSystem
{
    public partial class OrderConsume : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                requestNo.Value = "QM" + GetTimeStamp();

            }
        }

        public static string GetTimeStamp()
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalMilliseconds).ToString();
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            string merchantNo   = CustomerConfig.MerchantNo;
            string privatekey   = CustomerConfig.PrivateKey;
            string yopPublicKey = CustomerConfig.YopPublicKey;

            YopRequest request = new YopRequest(merchantNo, privatekey,
                 "https://open.yeepay.com/yop-center", yopPublicKey);

            request.addParam("requestNo", requestNo.Value);
            request.addParam("orderAmount", orderAmount.Value);
            request.addParam("fundAmount", fundAmount.Value);
            request.addParam("merchantOrderDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            request.addParam("serverCallbackUrl", "http://localhost:801/yopphpsdk/TranSystem/paycallback.php");
            request.addParam("webCallbackUrl", "http://localhost:801/yopphpsdk/TranSystem/paycallback.php");
            request.addParam("productCatalog", "5969");
            request.addParam("mcc", "5969");
            request.addParam("productName", productName.Value);
            request.addParam("productDesc", productDesc.Value);
            request.addParam("merchantUserId", merchantUserId.Value);
            request.addParam("bindCardId", bindCardId.Value);

            System.Diagnostics.Debug.WriteLine(request.toQueryString());
            YopResponse response = YopClient3.postRsa("/rest/v1.0/payplus/order/consume", request);


            if (response.isSuccess() && response.validSign)
            {
                Response.Write("返回结果签名验证成功!" + "<br>");
                Response.Write("response.resul:" + response.result + "<br>");
                JObject obj = (JObject)JsonConvert.DeserializeObject(response.result.ToString());
                requestNoRe.Text = Convert.ToString(obj["requestNo"]);
                redirectUrl.Text = Convert.ToString(obj["redirectUrl"]);
                orderAmountRe.Text = Convert.ToString(obj["orderAmount"]);
                fundAmountRe.Text = Convert.ToString(obj["fundAmount"]);
                status.Text = Convert.ToString(obj["status"]);
                code.Text = Convert.ToString(obj["code"]);
                message.Text = Convert.ToString(obj["message"]);
                divideCheck.Text = Convert.ToString(obj["divideCheck"]);
                divideErrorMassage.Text = Convert.ToString(obj["divideErrorMassage"]);
            }
            else
            {
                string errorText = JsonConvert.SerializeObject(response.error);
                Response.Write("请求失败，返回结果:" + errorText + "<br>");
            }

        }
    }
}