﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SDK.yop.client;
using SDK.yop.utils;
using System.Web.Util;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SDK.yop.encrypt;
using System.Net;



namespace RsaTest
{
    public partial class CallBack : System.Web.UI.Page
    {


            void Page_Load(Object src, EventArgs e)
        {

            string privatekey = CustomerConfig.PrivateKey;
            string yopPublicKey = CustomerConfig.YopPublicKey;
            string merchantNo = CustomerConfig.MerchantNo;

            string response = Request.Params["response"];
            string sourceData = SHA1withRSA.NoticeDecrypt(response, privatekey, yopPublicKey);
            JObject obj = (JObject)JsonConvert.DeserializeObject(sourceData);//序列化
            Response.Write("SUCCESS");
            returnData.Text = Convert.ToString(obj);
        }

    }
}

