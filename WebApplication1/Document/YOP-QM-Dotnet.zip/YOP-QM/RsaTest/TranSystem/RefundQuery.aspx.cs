﻿using System;
using SDK.yop.client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RsaTest.TranSystem
{
    public partial class RefundQuery : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click1(object sender, EventArgs e)
        {
            string merchantNo = CustomerConfig.MerchantNo;
            string privatekey = CustomerConfig.PrivateKey;
            string yopPublicKey = CustomerConfig.YopPublicKey;

            YopRequest request = new YopRequest(merchantNo, privatekey,
                 "https://open.yeepay.com/yop-center", yopPublicKey);

            request.addParam("trxRequestNo", trxRequestNo.Value);
            request.addParam("refundRequestNo", refundRequestNo.Value);


            System.Diagnostics.Debug.WriteLine(request.toQueryString());
            YopResponse response = YopClient3.postRsa("/rest/v1.0/payplus/refund/query", request);


            if (response.isSuccess() && response.validSign)
            {
                Response.Write("返回结果签名验证成功!" + "<br>");
                Response.Write("response.resul:" + response.result + "<br>");
                JObject obj = (JObject)JsonConvert.DeserializeObject(response.result.ToString());

                code.Text = Convert.ToString(obj["code"]);
                message.Text = Convert.ToString(obj["message"]);
                refundOrderList.Text = Convert.ToString(obj["refundOrderList"]);
            }
            else
            {
                string errorText = JsonConvert.SerializeObject(response.error);
                Response.Write("请求失败，返回结果:" + errorText + "<br>");
            }

        }
    }
}